#Parameters:
#MapHeap:	mapred.map.child.java.opts
#RedHeap:	mapred.reduce.java.opts
#SortMB	:	io.sort.mb
#SortPer:	io.sort.percent
#JvmReuse:	mapred.job.reuse.jvm.num.task

import os
import math


EXP = "/home/trend-hadoop/expr"
#TaskHeapSize = "-Xmx512M"
#SortHeapSize = "-Xmx100M"

#the amount of map tasks: 75

Parameter = '134217728'
NumMapTask = 'mapred.min.split.size'

for i in range(3):
	
	cmd = 'cp -r '+EXP+'/conf/conf_default '+EXP+'/conf/conf_new'
	os.system(cmd)

	cmd = EXP+'/tinyxml/revise_conf_v1 '+NumMapTask+' '+Parameter
	os.system(cmd)

	cmd = 'hadoop --config '+EXP+'/conf/conf_new jar '+EXP+'/../hadoop-1*/hadoop-examples* terasort /tera-in10G /tera-out'
	os.system(cmd)


	cmd = 'hadoop fs -get /tera-out/_logs '+EXP+'/counterEX/ex1/'
	os.system(cmd)	

	cmd = 'mv '+EXP+'/counterEX/ex1/_logs '+EXP+'/counterEX/ex1/log'+str(i)
	os.system(cmd)

	cmd = 'hadoop fs -rmr /tera-out'
	os.system(cmd)

	cmd = 'rm -rf '+EXP+'/conf/conf_new'
	os.system(cmd)


