import commands
import linecache
import json
import os
import sys
import numpy as np
import math
EXP = '/home/trend-hadoop/expr'
Hadoop = '/home/trend-hadoop/hadoop-1.2.1'
Des_path =EXP+'/implementation/v1/logs.json'
Rumen_libs = Hadoop+'/hadoop-tools-1.2.1.jar:'+Hadoop+'/hadoop-core-1.2.1.jar:'+Hadoop+'/lib/*'
RawDB = 'terasort'
RefineDB = 'terasort_refine'





class Log:
	def __init__(self,log_path):
		self.log_path = log_path



	def GetExecTime(self,raw_log_json):
		finishTime = -1	
		for other_task in raw_log_json['otherTasks']:
			if other_task["taskType"] == "SETUP":
				#	print "start"	
				startTime=other_task["startTime"]
				#	print startTime
			if other_task["taskType"] == "CLEANUP":
				#        print "finish"
				finishTime=other_task["finishTime"]
				#	print finishTime

		if finishTime==-1:
			exec_time = -1
		else:	
			exec_time = finishTime-startTime

		return exec_time

	def GetMapExecTime(self,raw_log_json):
		map_execTime_list = []
		for map_task in raw_log_json['mapTasks']:
			if map_task['taskStatus'] == 'SUCCESS':
				map_execTime = map_task['finishTime']-map_task['startTime']
				map_execTime_list.append(map_execTime)
		return map_execTime_list

	def GetRedExecTime(self,raw_log_json):
		reduce_execTime_list = []
		for reduce_task in raw_log_json['reduceTasks']:
			if reduce_task['taskStatus'] == 'SUCCESS':
				reduce_execTime = reduce_task['finishTime']-reduce_task['startTime']
				reduce_execTime_list.append(reduce_execTime)
		return reduce_execTime_list







	def RefineRawJson(self):
		raw_log_json_fstream = open(self.log_path)
		raw_log_json = json.load(raw_log_json_fstream)
		
		
		exec_time = self.GetExecTime(raw_log_json)				

		map_execTime_list = self.GetMapExecTime(raw_log_json)
		reduce_execTime_list = self.GetRedExecTime(raw_log_json)

		map_wave=math.ceil(float(len(map_execTime_list))/16)
		reduce_wave=math.ceil(float(len(reduce_execTime_list))/16)
		map_med=np.median(map_execTime_list)
		reduce_med=np.median(reduce_execTime_list)
		predict_time=map_wave*map_med+reduce_wave*reduce_med
	
		map_dev=np.std(map_execTime_list)

		MAPE=math.fabs(exec_time-predict_time)/exec_time
		if MAPE>0.10:
			print "real exec time;"+str(exec_time)
			print MAPE
			print map_med
			print map_dev


def ListDir(path):
	return os.listdir(path)



current_path = os.getcwd();


log_path=str(sys.argv[1])
new_log = Log(log_path)
new_log.RefineRawJson()
