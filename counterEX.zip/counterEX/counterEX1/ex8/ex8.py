#Parameters:
#MapHeap:	mapred.map.child.java.opts
#RedHeap:	mapred.reduce.java.opts
#SortMB	:	io.sort.mb
#SortPer:	io.sort.percent
#JvmReuse:	mapred.job.reuse.jvm.num.task

import os
import math


EXP = "/home/trend-hadoop/expr"
#TaskHeapSize = "-Xmx512M"
#SortHeapSize = "-Xmx100M"

#MapHeap = "mapred.map.child.java.opts "+TaskHeapSize
#RedHeap = "mapred.reduce.java.opts "+TaskHeapSize
#SortMB = "io.sort.mb "+SortHeapSize
#SortPer = "io.sort.percent 0.7"
#JvmReuse = "mapred.job.reuse.jvm.num.task -1"
Parameter = '201326592'
NumMapTask = 'mapred.min.split.size'

for i in range(3):
	
	cmd = 'cp -r '+EXP+'/conf/conf_default '+EXP+'/conf/conf_new'
	os.system(cmd)

	cmd = EXP+'/tinyxml/revise_conf_v1 '+NumMapTask+' '+Parameter+' mapred.job.reuse.jvm.num.tasks -1'
	os.system(cmd)

	cmd = 'hadoop --config '+EXP+'/conf/conf_new jar '+EXP+'/../hadoop-1*/hadoop-examples* terasort /tera-in10G /tera-out'
	os.system(cmd)


	cmd = 'hadoop fs -get /tera-out/_logs '+EXP+'/counterEX/ex8/'
	os.system(cmd)	

	cmd = 'mv '+EXP+'/counterEX/ex8/_logs '+EXP+'/counterEX/ex8/log'+str(i)
	os.system(cmd)

	cmd = 'hadoop fs -rmr /tera-out'
	os.system(cmd)

	cmd = 'rm -rf '+EXP+'/conf/conf_new'
	os.system(cmd)


