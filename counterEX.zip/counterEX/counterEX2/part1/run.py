#Parameters:


#MapHeapSize:mapred.map.child.java.opts
#MapTasksMax:mapred.tasktracker.map.tasks.max
#SplitSize:mapred.min.split.size
#SortMB:io.sort.mb
#SortPer:io.sort.spill.percent
#RecordPer:io.sort.record.percent
#JVMReuse:mapred.job.reuse.jvm.num.task

import os
import math
import json
import commands

EXP = "/home/trend-hadoop/expr"


JVMReuse = ' mapred.job.reuse.jvm.num.tasks '




def run_job(para_list,num):
		
	cmd = 'cp -r '+EXP+'/conf/conf_default '+EXP+'/conf/conf_new'
	os.system(cmd)
	


	DataSize = 10
	

	cmd = EXP+'/tinyxml/revise_conf_v1'+JVMReuse+str(para_list[0])
	os.system(cmd)

	
	cur_Path = lambda: commands.getoutput('pwd')

	cmd = 'hadoop --config '+EXP+'/conf/conf_new jar '+EXP+'/../hadoop-1*/hadoop-examples* terasort /tera-in'+str(DataSize)+'G /tera-out'
	os.system(cmd)

					
	cmd = 'hadoop fs -get /tera-out/_logs '+cur_Path()+'/logs/log_'+str(num+38)
	os.system(cmd)	


	cmd = 'hadoop fs -rmr /tera-out'
	os.system(cmd)
	
		
	cmd = 'rm -rf '+EXP+'/conf/conf_new'
	os.system(cmd)
	





ran_file = open('para_file','r')
num=0
for para_str in ran_file:
		
	data_list = json.loads(para_str)
	run_job(data_list,num)


	num=num+1
ran_file.close()
