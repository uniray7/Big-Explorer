import random
import sys
import json

def random_generator(NumRecord):
	ran_file = open('para_file','w')
	for i in range(NumRecord):

		for j in range(13):
		
			JVMReuse = lambda:-1 if j is 0 else j
	
			para_list = [JVMReuse()]
		
			data_json = json.dumps(para_list)
			print>>ran_file, data_json
	

	ran_file.close()

random_generator(int(sys.argv[1]))
